// Agrega eventos en los botones de horarios
document.querySelectorAll('.times button').forEach(button => {
    button.addEventListener('click', () => {
        alert(`Has seleccionado el horario: ${button.textContent}`);
    });
});
