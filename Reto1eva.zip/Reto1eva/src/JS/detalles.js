document.addEventListener('DOMContentLoaded', () => {
    const idPelicula = localStorage.getItem('idPelicula');
    if (!idPelicula) {
        console.error('ID de película no encontrado en localStorage');
        return;
    }

    console.log(`https://localhost:7103/Sesion/sesionesPelicula/${idPelicula}`);


    function fetchInfoPelicula() {
        fetch(`https://localhost:7103/Pelicula/${idPelicula}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al obtener los datos de la API');
                }
                return response.json();
            })
            .then(data => {
                mostrarPelicula(data);
            })
            .catch(error => console.error('Error al obtener datos de la película:', error));
    }

    function fetchInfoSesion() {
        fetch(`https://localhost:7103/Sesion/sesionesPelicula/${idPelicula}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al obtener los datos de la API');
                }
                return response.json();
            })
            .then(data => {
                console.log("Sesiones recibidas:", data); 
                mostrarSesiones(data);
            })
            .catch(error => console.error('Error al obtener datos de las sesiones:', error));
    }


    function mostrarPelicula(pelicula) {
        const mostrarDetalles = document.getElementById('mostrarDetalles');
        mostrarDetalles.innerHTML = `
            <img src="../src/img/${pelicula.imagen}" class="poster" alt="Póster de ${pelicula.nombre}">
            <div class="details">
                <h1>${pelicula.nombre}</h1>
                <p>${pelicula.descripcion}</p>
                <p><strong>Director:</strong> ${pelicula.director}</p>
                <p><strong>Duración:</strong> ${pelicula.duracion} minutos</p>
                <p><strong>Categorías:</strong> ${pelicula.categorias.join(', ')}</p>
                <p><strong>Valoración:</strong> ${pelicula.valoracion}</p>
            </div>
        `;
    }


    function mostrarSesiones(sesiones) {
        const mostrarDetalles = document.getElementById('mostrarDetalles');
        const sesionesHTML = sesiones.map(sesion => {
            const fechaInicio = new Date(sesion.fechaInicio);
            const fechaFormato = fechaInicio.toLocaleDateString('es-ES', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
            const horaFormato = fechaInicio.toLocaleTimeString('es-ES', {
                hour: '2-digit',
                minute: '2-digit'
            });

            return `
                <div class="sesion">
                    <button data-sala="${sesion.sala.numero}" id="${sesion.id}" onclick="Reservas('${sesion.id}')">
                        ${fechaFormato} - ${horaFormato} - Sala ${sesion.sala.numero}
                    </button>
                </div>
            `;
        }).join('');

        mostrarDetalles.innerHTML += `
            <div class="times">
                <h2>Salas disponibles:</h2>
                ${sesionesHTML}
            </div>
        `;

        document.querySelectorAll('.times button').forEach(button => {
            button.addEventListener('click', () => {
                alert(`Has seleccionado el horario: ${button.textContent}`);
            });
        });
    }
    fetchInfoPelicula();
    fetchInfoSesion();
});


function Reservas(sesionId) {
    localStorage.setItem('idSesion', sesionId)
    window.location.href = `reservas.html?id=${sesionId}`;
}

    


