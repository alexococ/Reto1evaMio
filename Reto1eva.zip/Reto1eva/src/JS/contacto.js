$(document).ready(function () {
    
  $("form").submit(function (e) {
      e.preventDefault(); 

      // Recopila los datos del formulario 
      var formData = {
          name: $("#name").val(),   
          phone: $("#phone").val(), 
          email: $("#email").val(), 
          message: $("#message").val() 
      };

      // Envía los datos del formulario 
      $.ajax({
          url: "https://formsubmit.co/cinesapop@gmail.com", 
          method: "POST", 
          data: formData,
          
          // alerta de éxito 
          success: function () {
              Swal.fire({
                  icon: "success", 
                  title: "¡Gracias por su ayuda!", 
                  text: "Si quieres volver y comprar entradas, puedes darle a la flecha.", 
                  confirmButtonText: "¡Volver a la página!", 
                  confirmButtonColor: "#934DEE" 
              });
          },

          // alerta de error
          error: function () {
              Swal.fire({
                  icon: "error", 
                  title: "Error", 
                  text: "Ocurrió un error al enviar el formulario, intenta de nuevo.", 
                  confirmButtonText: "Intentar de nuevo" 
              });
          }
      });
  });
});
