$(document).ready(function () {
    $("form").submit(function (e) {
      e.preventDefault(); 


      var formData = {
        name: $("#name").val(),
        phone: $("#phone").val(),
        email: $("#email").val(),
        message: $("#message").val(),
      };

      $.ajax({
        url: "https://formsubmit.co/cinesapop@gmail.com", 
        method: "POST", 
        data: formData, 
        success: function () {
          Swal.fire({
            icon: "success",
            title: "¡Gracias por su ayuda!",
            text: "Si quieres volver y comprar entradas, puedes darle a la flecha.",
            confirmButtonText: "¡Volver a la página!",
            confirmButtonColor: "#934DEE",
          });
        },
        error: function () {
          Swal.fire({
            icon: "error",
            title: "Error",
            text: "Ocurrió un error al enviar el formulario, intenta de nuevo.",
            confirmButtonText: "Intentar de nuevo",
          });
        },
      });
    });
  });