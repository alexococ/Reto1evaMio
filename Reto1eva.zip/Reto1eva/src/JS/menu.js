/* ---------------------------------------------- MENU DESPLEGABLE ---------------------------------------------- */
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})


function fetchPeliculas() {
    fetch('https://localhost:7103/Pelicula')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error al obtener los datos de la API');
            }
            return response.json();
        })
        .then(data => {
            mostrarPeliculas(data); // Llama a la función para mostrar las cartas
        })
        .catch(error => console.error('Error al obtener películas:', error));
}

// Función para generar y mostrar las cartas de las películas
function mostrarPeliculas(peliculas) {
    console.log(peliculas)
    const moviesContainer = document.querySelector('.obras-container');
    moviesContainer.innerHTML = '';

    peliculas.forEach(pelicula => {
        const peliculaHTML = `
            <div class="movie-card">
                <img src="../img/img_normales/${pelicula.imagenPequeniaUrl}" alt="${pelicula.nombre}" class="movie-card__image">
                <h3 class="movie-card__title">${pelicula.nombre}</h3>
                <button class="movie-card__button" onclick="verMasInformacion('${pelicula.id}')">Más Información</button>
            </div>
        `;
        moviesContainer.innerHTML += peliculaHTML; // Añade la carta al contenedor
    });
}