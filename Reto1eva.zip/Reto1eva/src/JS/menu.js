let menu = document.querySelector('#menu-icon'); 
let navbar = document.querySelector('.header__navbar'); 


menu.onclick = () => {
    menu.classList.toggle('bx-x'); 
    navbar.classList.toggle('open'); 
};


const nav = document.querySelector('.header__navbar'); 
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0); 
});

//Función para obtener películas desde la API 
function fetchPeliculas() {
    fetch('https://localhost:7103/Pelicula') 
        .then(response => {
            if (!response.ok) { 
                throw new Error('Error al obtener los datos de la API');
            }
            return response.json(); 
        })
        .then(data => {
            mostrarPeliculas(data); 
        })
        .catch(error => console.error('Error al obtener películas:', error)); 
}

//Función para mostrar las películas en la página 
function mostrarPeliculas(peliculas) {
    console.log(peliculas); 

    const moviesContainer = document.querySelector('#peliculas-container'); 
    moviesContainer.innerHTML = ''; 

    // HTML para cada pelicula.
    peliculas.forEach(pelicula => {
        const peliculaHTML = `
            <div class="movie-card">
                <img src="../src/img/${pelicula.imagen}" alt="${pelicula.nombre}" class="movie-card__image">
                <h3 class="movie-card__title">${pelicula.nombre}</h3>
                <button class="movie-card__button" onclick="Detalles('${pelicula.id}')">Más Información</button>
            </div>
        `;
        moviesContainer.innerHTML += peliculaHTML; 
    });
}


function Detalles(movieId) {
    localStorage.setItem('idPelicula', movieId); // Guarda el ID de la película seleccionada en localStorage.
    window.location.href = `detalles.html?id=${movieId}`; 
}


document.addEventListener('DOMContentLoaded', () => {
    fetchPeliculas(); 
});
