

/* ---------------------------------------------- MENU DESPLEGABLE ---------------------------------------------- */
let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x');
    navbar.classList.toggle('open');
}

const nav = document.querySelector('.header__navbar');
window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0)
})



    const todasObras = [
        
    ];



    // Función para actualizar la lista de obras en el contenedor
    function actualizarObras(listaDeObras) {
        // Limpiar el contenedor
        obrasContainer.innerHTML = '';

        // Agregar las obras al contenedor
        listaDeObras.forEach(obra => {
            const cardProduct = document.createElement('div');
            cardProduct.classList.add('card-product');

            const containerImg = document.createElement('div');
            containerImg.classList.add('container-img');

            const imgItem = document.createElement('img');
            imgItem.src = obra.imagen;
            imgItem.alt = obra.titulo;
            imgItem.classList.add('img-item');

            containerImg.appendChild(imgItem);

            const contentCardProduct = document.createElement('div');
            contentCardProduct.classList.add('content-card-product');

            const tituloItem = document.createElement('h3');
            tituloItem.classList.add('titulo-item');
            tituloItem.textContent = obra.titulo;

            const detallesLink = document.createElement('a');
            detallesLink.href = `detalles.html?titulo=${encodeURIComponent(obra.titulo)}`;

            const detallesButton = document.createElement('button');
            detallesButton.classList.add('obras-button');
            detallesButton.textContent = 'Detalles';

            detallesLink.appendChild(detallesButton); 
            contentCardProduct.appendChild(tituloItem);
            contentCardProduct.appendChild(detallesLink); 

            cardProduct.appendChild(containerImg);
            cardProduct.appendChild(contentCardProduct);

            obrasContainer.appendChild(cardProduct);
        });
    }

    // Llamada inicial para mostrar todas las obras al cargar la página
    actualizarObras(todasObras);



/* ---------------------------------------------- FLECHA DE DESPLAZAMIENTO A LAS OBRAS DE TEATRO ---------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const arrow = document.getElementById('arrow');
    const arrowFinal = document.getElementById('arrow-final');

    // Manejar clic en la flecha
    arrow.addEventListener('click', () => {
        // Utilizar el método `scrollIntoView` para desplazamiento suave
        arrowFinal.scrollIntoView({ behavior: 'smooth' });
    });
});








/* ---------------------------------------------- CARGAR LAS OBRAS DE TEATRO PINTANDO EN EL HTML ---------------------------------------------- */

document.addEventListener('DOMContentLoaded', () => {
    const obrasContainer = document.getElementById('obras-container');

    // Hacer una solicitud a la API REST para obtener datos
    fetch('http://localhost:3000/api/obras')
        .then(response => response.json())
        .then(data => {
            // Iterar sobre los datos y crear tarjetas de obra
            data.forEach(obra => {
                const cardProduct = document.createElement('div');
                cardProduct.classList.add('card-product');

                const containerImg = document.createElement('div');
                containerImg.classList.add('container-img');

                const imgItem = document.createElement('img');
                imgItem.src = obra.imagen;
                imgItem.alt = obra.titulo;
                imgItem.classList.add('img-item');

                containerImg.appendChild(imgItem);

                const contentCardProduct = document.createElement('div');
                contentCardProduct.classList.add('content-card-product');

                const tituloItem = document.createElement('h3');
                tituloItem.classList.add('titulo-item');
                tituloItem.textContent = obra.titulo;

                const detallesButton = document.createElement('button');
                detallesButton.classList.add('obras-button');
                detallesButton.textContent = 'Detalles';

                contentCardProduct.appendChild(tituloItem);
                contentCardProduct.appendChild(detallesButton);

                cardProduct.appendChild(containerImg);
                cardProduct.appendChild(contentCardProduct);

                obrasContainer.appendChild(cardProduct);
            });
        })
        .catch(error => console.error('Error al obtener datos de la API:', error));
});








