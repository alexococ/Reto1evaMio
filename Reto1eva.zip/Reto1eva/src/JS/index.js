let menu = document.querySelector('#menu-icon');
let navbar = document.querySelector('.header__navbar');

menu.onclick = () => {
    menu.classList.toggle('bx-x'); 
    navbar.classList.toggle('open'); 
};


window.addEventListener('scroll', function () {
    navbar.classList.toggle('active', window.scrollY > 0); 
});

document.addEventListener('DOMContentLoaded', () => {
    const slider = document.querySelector('.slider'); 
    const slides = document.querySelectorAll('.slide'); 
    const prevButton = document.querySelector('.slider-control.prev'); 
    const nextButton = document.querySelector('.slider-control.next'); 
    const navDots = document.querySelectorAll('.nav-dot'); 
    let currentIndex = 0; 

    const updateSlider = () => {
        slider.style.transform = `translateX(-${currentIndex * 100}%)`;


        navDots.forEach(dot => dot.classList.remove('active')); 
        navDots[currentIndex].classList.add('active'); 
    };

 
    prevButton.addEventListener('click', () => {
        currentIndex = (currentIndex === 0) ? slides.length - 1 : currentIndex - 1; 
        updateSlider(); 
    });

    nextButton.addEventListener('click', () => {
        currentIndex = (currentIndex === slides.length - 1) ? 0 : currentIndex + 1; 
        updateSlider(); 
    });


    navDots.forEach((dot, index) => {
        dot.addEventListener('click', (e) => {
            e.preventDefault(); 
            currentIndex = index; 
            updateSlider(); 
        });
    });


    setInterval(() => {
        nextButton.click(); 
    }, 5000);
});
