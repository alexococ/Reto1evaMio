document.addEventListener('DOMContentLoaded', () => {
    const seatsContainer = document.querySelector('.seats');
    const reservationCount = document.getElementById('reservation-count');
    const reserveButton = document.getElementById('reserve-button');
    const sesionId = localStorage.getItem('idSesion');
    const llamada = `https://localhost:7103/Sesion/${sesionId}`;

    let selectedSeats = []; 

    function formatearFechaHora(fechaISO) {
        const fecha = new Date(fechaISO);
        const dia = fecha.getDate().toString().padStart(2, '0');
        const mes = (fecha.getMonth() + 1).toString().padStart(2, '0');
        const anio = fecha.getFullYear();
        const horas = fecha.getHours().toString().padStart(2, '0');
        const minutos = fecha.getMinutes().toString().padStart(2, '0');
        return `${dia}/${mes}/${anio} ${horas}:${minutos}`;
    }

    function mostrarDetallesPelicula(sesion) {
        localStorage.setItem('sesion', JSON.stringify(sesion));
        const mostrarDetalles = document.querySelector('.movie-info');
        if (!mostrarDetalles) {
            console.error("Elemento .movie-info no encontrado");
            return;
        }

        const fechaHoraFormateada = formatearFechaHora(sesion.fechaInicio);

        mostrarDetalles.innerHTML = `
            <img src="../src/img/${sesion.pelicula.imagen}" class="poster" alt="Póster de ${sesion.pelicula.nombre}" style="width: 300px; height: auto;">
            <div class="movie-details">
                <h1>${sesion.pelicula.nombre}</h1>
                <p><strong>Director:</strong> ${sesion.pelicula.director}</p>
                <p><strong>Duración:</strong> ${sesion.pelicula.duracion} minutos</p>
                <p>Sala ${sesion.sala.numero} - ${fechaHoraFormateada}</p>
            </div>
        `;
    }

    function mostrarAsientos(sesion) {
        if (!seatsContainer) {
            console.error("Elemento .seats no encontrado");
            return;
        }

        // Limpia el contenedor antes de añadir nuevos asientos
        seatsContainer.innerHTML = '';

        sesion.listaAsientos.forEach(asiento => {
            const seat = document.createElement('div');
            seat.classList.add('seat');
            seat.id = `seat-${asiento.id}`;

            if (asiento.ocupado) {
                seat.classList.add('occupied');
            } else {
                seat.classList.add('available');
                // Agrega evento para seleccionar asientos disponibles
                seat.addEventListener('click', () => seleccionarAsiento(asiento.id, seat));
            }

            seatsContainer.appendChild(seat);
        });
    }

    function seleccionarAsiento(asientoId, seatElement) {
        if (seatElement.classList.contains('selected')) {
            // Deseleccionar asiento
            seatElement.classList.remove('selected');
            selectedSeats = selectedSeats.filter(id => id !== asientoId);
        } else {
            // Seleccionar asiento
            seatElement.classList.add('selected');
            selectedSeats.push(asientoId);
        }

        // Guardar los asientos seleccionados en localStorage
        localStorage.setItem('selectedSeats', JSON.stringify(selectedSeats));

        // Actualizar el contador de reservas
        reservationCount.textContent = selectedSeats.length;
    }

    function reservarAsientos() {
        if (selectedSeats.length === 0) {
            alert('Por favor, selecciona al menos un asiento para reservar.');
            return;
        }

        fetch(`https://localhost:7103/Sesion/actualizarAsientos/${sesionId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(selectedSeats),
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al realizar la reserva');
                }
            })
            .then(data => {
                alert('Reserva realizada con éxito');
                console.log('Reserva exitosa:', data);
                // Recargar datos de la sesión para actualizar el estado de los asientos
                localStorage.setItem('aAsientosId', JSON.stringify(selectedSeats));
                window.location.href = `pagar.html`;
            })
            .catch(error => {
                console.error('Error al reservar asientos:', error);
                alert('Hubo un problema al realizar la reserva. Intenta nuevamente.');
            });
    }

    function fetchInfoSesion() {
        fetch(llamada)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Error al obtener los datos de la API');
                }
                return response.json();
            })
            .then(data => {
                console.log("Sesiones recibidas:", data);
                mostrarAsientos(data);
                mostrarDetallesPelicula(data);
            })
            .catch(error => console.error('Error al obtener datos de las sesiones:', error));
    }

    // Inicializar evento del botón de reservar
    reserveButton.addEventListener('click', reservarAsientos);

    fetchInfoSesion();
});
