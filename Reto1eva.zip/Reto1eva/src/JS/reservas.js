document.addEventListener('DOMContentLoaded', () => {
    const seatsContainer = document.querySelector('.seats');
    const reservationCount = document.getElementById('reservation-count');
    const reserveButton = document.getElementById('reserve-button');
    const rows = 8; 
    const columns = 10; 

    
    let selectedSeatsCount = 0;  
    reservationCount.textContent = selectedSeatsCount; 

    
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < columns; j++) {
            const seat = document.createElement('div');
            seat.classList.add('seat');
            if (Math.random() < 0.3) {
                seat.classList.add('occupied');
            }
            seat.addEventListener('click', () => toggleSeatSelection(seat));
            seatsContainer.appendChild(seat);
        }
    }


    function toggleSeatSelection(seat) {
        
        if (!seat.classList.contains('occupied')) {
            if (seat.classList.contains('selected')) {
                
                seat.classList.remove('selected');
                selectedSeatsCount--;  
            } else {
                
                seat.classList.add('selected');
                selectedSeatsCount++;  
            }
            updateReservationInfo();  
        }
    }

   
    function updateReservationInfo() {
        
        reservationCount.textContent = selectedSeatsCount;
    }

    
    reserveButton.addEventListener('click', () => {
        if (selectedSeatsCount > 0) {
            const selectedSeats = document.querySelectorAll('.seat.selected');
            selectedSeats.forEach(seat => {
                seat.classList.remove('selected');
                seat.classList.add('occupied');
            });
            selectedSeatsCount = 0; 
            updateReservationInfo();  
            alert(`Has reservado ${selectedSeats.length} entrada(s).`);
        } else {
            alert('Por favor, selecciona al menos un asiento.');
        }
    });
});
