 const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());

const staticPath = path.join(__dirname, 'src');
app.use(express.static(staticPath));


app.get('/', (req, res) => {
  res.sendFile(path.join(staticPath, 'index.html'));
});

app.get('/obras-page', (req, res) => {
  res.sendFile(path.join(staticPath, 'menu.html'));
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
