 const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.json());
app.use(cors());

// Configurar la carpeta de archivos estáticos
const staticPath = path.join(__dirname, 'src');
app.use(express.static(staticPath));

// Definir una ruta para la página principal
app.get('/', (req, res) => {
  res.sendFile(path.join(staticPath, 'index.html'));
});

// Definir una ruta para obtener la página de "Obras"
app.get('/obras-page', (req, res) => {
  res.sendFile(path.join(staticPath, 'menu.html'));
});

// Definir una ruta para obtener datos de "Obras" (en formato JSON, por ejemplo)
app.get('/api/obras', (req, res) => {
  const todasObras = [
    { titulo: 'Red One', imagen: './src/img/redOne.jpg' },
    { titulo: 'Venom 3', imagen: ':/src/img/Venom.jpg' },
    { titulo: 'Terrifier 3', imagen: './src/img/terrifier3.jpg' },
    { titulo: 'Robot Salvaje', imagen: './src/img/robotSalvaje.jpg' },
    { titulo: 'Gladiator 2', imagen: './src/img/gladiator.jpg' },
    { titulo: 'Nunca te Sueltes', imagen: './src/img/nuncaTeSueltes.jpg' },
    { titulo: 'Vaiana 2', imagen: './src/img/Vaiana.jpg' },
    { titulo: 'Bitelchus', imagen: './src/img/bitelchus.jpg' },
    { titulo: 'Deadpool y Lobezno', imagen: './src/img/deadpool.jpg' },
];
  res.json(todasObras);
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
