using models;
using System;
using System.Collections.Generic;

public static class InicializadorDatos
{
    public static void InicializarDatos()
    {
        InicializarPeliculas();
        InicializarSalas();
        InicializarSesiones();
        InicializarButacas();
    }

    private static void InicializarPeliculas()
    {

        DataStore.Peliculas.AddRange(new List<Pelicula>
        {
            new Pelicula(
        nombre: "Terrifier 3",
        descripcion: "Art el Payaso regresa en una secuela aún más aterradora, sembrando el caos en un pueblo.",
        director: "Damien Leone",
        categorias: new[] { "Terror", "Gore" },
        anioDeSalida: new DateTime(2024, 10, 25),
        imagen: "terrifier3.jpg",
        duracion: 118,
        valoracion: 7.80
    ),
    new Pelicula(
        nombre: "Avatar 2: El Camino del Agua",
        descripcion: "Jake Sully y Neytiri deben proteger a su familia mientras exploran los océanos de Pandora.",
        director: "James Cameron",
        categorias: new[] { "Ciencia Ficción", "Aventura", "Fantasía" },
        anioDeSalida: new DateTime(2022, 12, 16),
        imagen: "avatar2.jpg",
        duracion: 192,
        valoracion: 8.20
    ),
    new Pelicula(
        nombre: "Beetlejuice",
        descripcion: "Un matrimonio de fantasmas recurre a Beetlejuice para ahuyentar a los nuevos habitantes de su hogar.",
        director: "Tim Burton",
        categorias: new[] { "Comedia", "Fantasía" },
        anioDeSalida: new DateTime(1988, 3, 30),
        imagen: "bitelchus.jpg",
        duracion: 92,
        valoracion: 7.50
    ),
    new Pelicula(
        nombre: "Deadpool 3",
        descripcion: "El antihéroe sarcástico regresa para enfrentar un nuevo caos en el multiverso.",
        director: "Shawn Levy",
        categorias: new[] { "Acción", "Comedia", "Superhéroes" },
        anioDeSalida: new DateTime(2024, 5, 3),
        imagen: "deadpool.jpg",
        duracion: 120,
        valoracion: 8.00
    ),
    new Pelicula(
        nombre: "Gladiator 2",
        descripcion: "Una nueva historia épica se desarrolla en el mundo del antiguo Imperio Romano.",
        director: "Ridley Scott",
        categorias: new[] { "Drama", "Acción", "Histórica" },
        anioDeSalida: new DateTime(2024, 11, 22),
        imagen: "gladiator.jpg",
        duracion: 150,
        valoracion: 8.50
    ),
    new Pelicula(
        nombre: "Red One",
        descripcion: "Una aventura navideña repleta de acción y sorpresas mágicas.",
        director: "Jake Kasdan",
        categorias: new[] { "Acción", "Comedia", "Navidad" },
        anioDeSalida: new DateTime(2023, 12, 15),
        imagen: "redOne.jpg",
        duracion: 100,
        valoracion: 7.60
    ),
    new Pelicula(
        nombre: "Robot Salvaje",
        descripcion: "Un robot humanoide busca su propósito mientras enfrenta conflictos entre humanos y máquinas.",
        director: "Alex Garland",
        categorias: new[] { "Ciencia Ficción", "Drama" },
        anioDeSalida: new DateTime(2025, 6, 18),
        imagen: "robotSalvaje.jpg",
        duracion: 128,
        valoracion: 8.10
    ),
    new Pelicula(
        nombre: "Vaiana 2",
        descripcion: "Vaiana navega más allá de los límites conocidos para salvar su hogar de una nueva amenaza.",
        director: "John Musker y Ron Clements",
        categorias: new[] { "Animación", "Aventura", "Fantasía" },
        anioDeSalida: new DateTime(2025, 7, 19),
        imagen: "Vaiana.jpg",
        duracion: 110,
        valoracion: 7.90
    ),
    new Pelicula(
        nombre: "Venom 3",
        descripcion: "Eddie Brock y Venom enfrentan un enemigo más poderoso que nunca.",
        director: "Kelly Marcel",
        categorias: new[] { "Acción", "Ciencia Ficción", "Superhéroes" },
        anioDeSalida: new DateTime(2024, 10, 4),
        imagen: "Venom.jpg",
        duracion: 130,
        valoracion: 7.50
    ),
    new Pelicula(
        nombre: "Nunca te Sueltes",
        descripcion: "Una pareja enfrenta adversidades extremas mientras intenta sobrevivir a una tragedia.",
        director: "Juan Carlos Fresnadillo",
        categorias: new[] { "Drama", "Romance", "Suspenso" },
        anioDeSalida: new DateTime(2025, 2, 14),
        imagen: "nuncaTeSueltes.jpg",
        duracion: 115,
        valoracion: 7.70
    )
});
    }

    private static void InicializarSalas()
    {
        DataStore.Salas.AddRange(new List<Sala>{
            new Sala(
                numero: "1",
                tipo: "3D",
                capacidad: 30
            ),

            new Sala(
                numero: "2",
                tipo: "Estandar",
                capacidad: 50
            ),

            new Sala(
                numero: "3",
                tipo: "3D",
                capacidad: 30
            ),

            new Sala(
                numero: "4",
                tipo: "Estandar",
                capacidad: 30
            ),

            new Sala(
                numero: "5",
                tipo: "Audio Dolby",
                capacidad: 40
            ),
        });
    }

    private static void InicializarButacas()
    {

    }

    private static void InicializarSesiones()
    {

    }


}
